#!/usr/bin/env python3
"""
Comfy Gallery - Universal ComfyUI Output Browser
================================================
A fast, beautiful gallery to organize and browse all your ComfyUI outputs.
Features metadata extraction, workflow download, and multi-folder support.

Usage:
    python comfy_gallery.py

Open in browser:
    http://localhost:8188

Repository: https://github.com/YOUR_USERNAME/comfy-gallery
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Dopamine Fact"

import os
import sys
import json
import struct
import zlib
import hashlib
import sqlite3
import threading
import random
import webbrowser
from pathlib import Path
from datetime import datetime
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor

from flask import Flask, render_template, send_file, jsonify, request, abort, redirect, url_for
from PIL import Image, ImageDraw

# =============================================================================
# CONFIGURATION
# =============================================================================

# Server settings
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8199  # Changed to avoid conflicts with ComfyUI (8188)

# Thumbnail settings
THUMBNAIL_SIZE = (300, 300)
THUMBNAIL_QUALITY = 85

# Supported formats
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tiff', '.tif'}
VIDEO_EXTENSIONS = {'.mp4', '.webm', '.mov', '.avi', '.mkv', '.flv', '.wmv', '.m4v'}
ANIMATED_EXTENSIONS = {'.gif', '.webp'}
ALL_EXTENSIONS = IMAGE_EXTENSIONS | VIDEO_EXTENSIONS

# Color palette for sources
COLOR_PALETTE = [
    "#8b5cf6", "#ec4899", "#3b82f6", "#22c55e", "#f59e0b",
    "#ef4444", "#06b6d4", "#84cc16", "#f97316", "#a855f7",
    "#14b8a6", "#eab308", "#6366f1", "#d946ef", "#0ea5e9"
]

# =============================================================================
# FLASK APPLICATION
# =============================================================================

app = Flask(__name__)

# Paths
BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "gallery.db"
CONFIG_PATH = BASE_DIR / "config.json"
CACHE_DIR = BASE_DIR / "cache" / "thumbnails"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

# =============================================================================
# CONFIG MANAGEMENT
# =============================================================================

def load_config():
    """Load configuration from file"""
    default_config = {
        'sources': [],
        'setup_complete': False,
        'theme': 'dark',
        'language': 'en'
    }
    
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # Merge with defaults
                for key in default_config:
                    if key not in config:
                        config[key] = default_config[key]
                return config
        except:
            pass
    return default_config

def save_config(config):
    """Save configuration to file"""
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

def get_sources():
    """Get list of output sources"""
    config = load_config()
    return config.get('sources', [])

def is_setup_complete():
    """Check if initial setup is complete"""
    config = load_config()
    return config.get('setup_complete', False) and len(config.get('sources', [])) > 0

def get_random_color():
    """Get a random color from palette"""
    return random.choice(COLOR_PALETTE)

# =============================================================================
# DATABASE
# =============================================================================

def init_db():
    """Initialize database"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filepath TEXT UNIQUE,
            filename TEXT,
            source_name TEXT,
            source_path TEXT,
            file_size INTEGER,
            file_hash TEXT,
            width INTEGER,
            height INTEGER,
            created_at TEXT,
            modified_at TEXT,
            file_type TEXT,
            prompt TEXT,
            negative_prompt TEXT,
            model TEXT,
            sampler TEXT,
            steps INTEGER,
            cfg REAL,
            seed TEXT,
            workflow_json TEXT,
            metadata_json TEXT,
            thumbnail_path TEXT,
            indexed_at TEXT,
            is_duplicate INTEGER DEFAULT 0
        )
    ''')
    
    c.execute('CREATE INDEX IF NOT EXISTS idx_created ON images(created_at DESC)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_source ON images(source_name)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_model ON images(model)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_hash ON images(file_hash)')
    
    # Add columns if they don't exist (for upgrades)
    for col, col_type in [('file_hash', 'TEXT'), ('is_duplicate', 'INTEGER DEFAULT 0')]:
        try:
            c.execute(f'ALTER TABLE images ADD COLUMN {col} {col_type}')
        except:
            pass
    
    conn.commit()
    conn.close()

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# =============================================================================
# PNG METADATA EXTRACTION
# =============================================================================

def read_png_chunks(filepath):
    """Read metadata chunks from PNG file"""
    chunks = {}
    try:
        with open(filepath, 'rb') as f:
            signature = f.read(8)
            if signature != b'\x89PNG\r\n\x1a\n':
                return chunks
            
            while True:
                chunk_header = f.read(8)
                if len(chunk_header) < 8:
                    break
                
                length = struct.unpack('>I', chunk_header[:4])[0]
                chunk_type = chunk_header[4:8].decode('ascii', errors='ignore')
                data = f.read(length)
                f.read(4)  # CRC
                
                if chunk_type == 'tEXt':
                    try:
                        null_idx = data.index(b'\x00')
                        key = data[:null_idx].decode('latin-1')
                        value = data[null_idx+1:].decode('latin-1')
                        chunks[key] = value
                    except:
                        pass
                
                elif chunk_type == 'iTXt':
                    try:
                        null_idx = data.index(b'\x00')
                        key = data[:null_idx].decode('utf-8')
                        rest = data[null_idx+1:]
                        if len(rest) >= 2:
                            compression = rest[0]
                            rest = rest[2:]
                            null_idx = rest.index(b'\x00')
                            rest = rest[null_idx+1:]
                            null_idx = rest.index(b'\x00')
                            value_data = rest[null_idx+1:]
                            
                            if compression:
                                value = zlib.decompress(value_data).decode('utf-8')
                            else:
                                value = value_data.decode('utf-8')
                            chunks[key] = value
                    except:
                        pass
                
                if chunk_type == 'IEND':
                    break
                    
    except Exception as e:
        pass
    
    return chunks

def extract_comfyui_metadata(chunks):
    """Extract information from ComfyUI metadata"""
    result = {
        'prompt': '',
        'negative_prompt': '',
        'model': '',
        'sampler': '',
        'steps': 0,
        'cfg': 0.0,
        'seed': '',
        'workflow': None,
        'raw_prompt': None
    }
    
    if 'workflow' in chunks:
        try:
            result['workflow'] = json.loads(chunks['workflow'])
        except:
            pass
    
    prompt_data = None
    if 'prompt' in chunks:
        try:
            prompt_data = json.loads(chunks['prompt'])
            result['raw_prompt'] = prompt_data
        except:
            pass
    
    if not prompt_data:
        return result
    
    positive_prompts = []
    negative_prompts = []
    
    for node_id, node_data in prompt_data.items():
        if not isinstance(node_data, dict):
            continue
        
        class_type = node_data.get('class_type', '')
        inputs = node_data.get('inputs', {})
        
        if 'KSampler' in class_type or 'sampler' in class_type.lower():
            if 'seed' in inputs:
                seed_val = inputs['seed']
                if isinstance(seed_val, (int, float)):
                    result['seed'] = str(int(seed_val))
            if 'steps' in inputs:
                try:
                    result['steps'] = int(inputs.get('steps', 0))
                except:
                    result['steps'] = 0
            if 'cfg' in inputs:
                try:
                    result['cfg'] = float(inputs.get('cfg', 0))
                except:
                    result['cfg'] = 0.0
            if 'sampler_name' in inputs:
                result['sampler'] = str(inputs['sampler_name'])
        
        if class_type in ['CLIPTextEncode', 'CLIPTextEncodeSDXL']:
            text = inputs.get('text', '')
            if isinstance(text, str) and text.strip():
                positive_prompts.append(text)
        
        if 'negative' in class_type.lower():
            text = inputs.get('text', '')
            if isinstance(text, str) and text.strip():
                negative_prompts.append(text)
        
        if 'CheckpointLoader' in class_type or 'Load Checkpoint' in class_type:
            ckpt = inputs.get('ckpt_name', '')
            if ckpt and isinstance(ckpt, str):
                result['model'] = ckpt
        
        if 'UNETLoader' in class_type:
            unet = inputs.get('unet_name', '')
            if unet and isinstance(unet, str):
                result['model'] = unet
    
    if positive_prompts:
        result['prompt'] = max(positive_prompts, key=len)
    if negative_prompts:
        result['negative_prompt'] = max(negative_prompts, key=len)
    
    return result

def get_image_metadata(filepath):
    """Extract all metadata from image file"""
    filepath = Path(filepath)
    ext = filepath.suffix.lower()
    
    result = {
        'prompt': '',
        'negative_prompt': '',
        'model': '',
        'sampler': '',
        'steps': 0,
        'cfg': 0.0,
        'seed': '',
        'workflow_json': None,
        'metadata_json': None,
        'width': 0,
        'height': 0
    }
    
    try:
        with Image.open(filepath) as img:
            result['width'], result['height'] = img.size
        
        if ext == '.png':
            chunks = read_png_chunks(filepath)
            if chunks:
                meta = extract_comfyui_metadata(chunks)
                result['prompt'] = meta['prompt']
                result['negative_prompt'] = meta['negative_prompt']
                result['model'] = meta['model']
                result['sampler'] = meta['sampler']
                result['steps'] = meta['steps']
                result['cfg'] = meta['cfg']
                result['seed'] = meta['seed']
                if meta['workflow']:
                    result['workflow_json'] = json.dumps(meta['workflow'])
                if meta['raw_prompt']:
                    result['metadata_json'] = json.dumps(meta['raw_prompt'])
                    
    except Exception as e:
        pass
    
    return result

# =============================================================================
# THUMBNAIL GENERATION
# =============================================================================

def get_thumbnail_path(filepath):
    """Calculate thumbnail path for file"""
    file_hash = hashlib.md5(str(filepath).encode()).hexdigest()
    ext = Path(filepath).suffix.lower()
    if ext in VIDEO_EXTENSIONS:
        return CACHE_DIR / f"{file_hash}_video.jpg"
    return CACHE_DIR / f"{file_hash}.jpg"

def create_thumbnail(filepath, thumb_path):
    """Create thumbnail for file"""
    filepath = Path(filepath)
    ext = filepath.suffix.lower()
    
    try:
        if ext == '.gif':
            with Image.open(filepath) as img:
                img.seek(0)
                if img.mode in ('RGBA', 'P', 'LA'):
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                
                img.thumbnail(THUMBNAIL_SIZE, Image.Resampling.LANCZOS)
                img.save(thumb_path, 'JPEG', quality=THUMBNAIL_QUALITY, optimize=True)
                return True
        
        elif ext in IMAGE_EXTENSIONS:
            with Image.open(filepath) as img:
                if img.mode in ('RGBA', 'P', 'LA'):
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    if img.mode == 'RGBA':
                        background.paste(img, mask=img.split()[-1])
                    else:
                        background.paste(img)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                
                img.thumbnail(THUMBNAIL_SIZE, Image.Resampling.LANCZOS)
                img.save(thumb_path, 'JPEG', quality=THUMBNAIL_QUALITY, optimize=True)
                return True
        
        elif ext in VIDEO_EXTENSIONS:
            return create_video_thumbnail(filepath, thumb_path)
            
    except Exception as e:
        pass
    
    return False

def create_video_thumbnail(video_path, thumb_path):
    """Create thumbnail for video using ffmpeg"""
    import subprocess
    import shutil
    
    ffmpeg_path = shutil.which('ffmpeg')
    if not ffmpeg_path:
        for path in ['ffmpeg', 'C:/ffmpeg/bin/ffmpeg.exe', 'C:/Program Files/ffmpeg/bin/ffmpeg.exe']:
            if Path(path).exists() or shutil.which(path):
                ffmpeg_path = path
                break
    
    if not ffmpeg_path:
        return create_video_placeholder(thumb_path)
    
    try:
        cmd = [
            ffmpeg_path, '-y',
            '-ss', '1',
            '-i', str(video_path),
            '-vframes', '1',
            '-vf', f'scale={THUMBNAIL_SIZE[0]}:{THUMBNAIL_SIZE[1]}:force_original_aspect_ratio=decrease',
            '-q:v', '2',
            str(thumb_path)
        ]
        
        subprocess.run(cmd, capture_output=True, timeout=30)
        
        if thumb_path.exists():
            return True
        
    except Exception as e:
        pass
    
    return create_video_placeholder(thumb_path)

def create_video_placeholder(thumb_path):
    """Create placeholder thumbnail for video"""
    try:
        img = Image.new('RGB', THUMBNAIL_SIZE, (30, 30, 35))
        draw = ImageDraw.Draw(img)
        
        cx, cy = THUMBNAIL_SIZE[0] // 2, THUMBNAIL_SIZE[1] // 2
        size = 40
        points = [
            (cx - size//2, cy - size),
            (cx - size//2, cy + size),
            (cx + size, cy)
        ]
        draw.polygon(points, fill=(139, 92, 246))
        draw.text((cx - 25, cy + size + 10), "VIDEO", fill=(150, 150, 150))
        
        img.save(thumb_path, 'JPEG', quality=85)
        return True
    except:
        return False

# =============================================================================
# FILE SCANNING
# =============================================================================

def calculate_file_hash(filepath, quick=True):
    """Calculate file hash for duplicate detection"""
    try:
        hasher = hashlib.md5()
        with open(filepath, 'rb') as f:
            if quick:
                f.seek(0)
                hasher.update(f.read(65536))
                f.seek(0, 2)
                size = f.tell()
                if size > 65536:
                    f.seek(-65536, 2)
                    hasher.update(f.read(65536))
                hasher.update(str(size).encode())
            else:
                for chunk in iter(lambda: f.read(8192), b''):
                    hasher.update(chunk)
        return hasher.hexdigest()
    except:
        return None

def scan_single_file(args):
    """Scan single file and add to database"""
    filepath, source_name, source_path = args
    filepath = Path(filepath)
    
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    c.execute('SELECT id, modified_at FROM images WHERE filepath = ?', (str(filepath),))
    existing = c.fetchone()
    
    try:
        stat = filepath.stat()
    except:
        conn.close()
        return None
        
    modified_at = datetime.fromtimestamp(stat.st_mtime).isoformat()
    
    if existing and existing['modified_at'] == modified_at:
        conn.close()
        return None
    
    file_hash = calculate_file_hash(filepath)
    
    is_duplicate = 0
    if file_hash:
        c.execute('SELECT id FROM images WHERE file_hash = ? AND filepath != ?', (file_hash, str(filepath)))
        if c.fetchone():
            is_duplicate = 1
    
    ext = filepath.suffix.lower()
    file_type = 'image' if ext in IMAGE_EXTENSIONS else 'video'
    
    if file_type == 'image':
        meta = get_image_metadata(filepath)
    else:
        meta = {
            'prompt': '', 'negative_prompt': '', 'model': '',
            'sampler': '', 'steps': 0, 'cfg': 0.0, 'seed': '',
            'workflow_json': None, 'metadata_json': None,
            'width': 0, 'height': 0
        }
    
    thumb_path = get_thumbnail_path(filepath)
    if not thumb_path.exists():
        create_thumbnail(filepath, thumb_path)
    
    created_at = datetime.fromtimestamp(stat.st_ctime).isoformat()
    
    def to_str(val, max_len=None):
        if val is None:
            return ''
        if isinstance(val, list):
            val = ', '.join(str(v) for v in val)
        val = str(val)
        if max_len:
            val = val[:max_len]
        return val
    
    data = (
        str(filepath),
        filepath.name,
        source_name,
        source_path,
        stat.st_size,
        file_hash,
        meta['width'],
        meta['height'],
        created_at,
        modified_at,
        file_type,
        to_str(meta['prompt'], 5000),
        to_str(meta['negative_prompt'], 2000),
        to_str(meta['model']),
        to_str(meta['sampler']),
        int(meta['steps']) if meta['steps'] else 0,
        float(meta['cfg']) if meta['cfg'] else 0.0,
        to_str(meta['seed']),
        meta['workflow_json'],
        meta['metadata_json'],
        str(thumb_path) if thumb_path.exists() else '',
        datetime.now().isoformat(),
        is_duplicate
    )
    
    try:
        if existing:
            c.execute('''
                UPDATE images SET
                    filename=?, source_name=?, source_path=?, file_size=?, file_hash=?,
                    width=?, height=?, created_at=?, modified_at=?, file_type=?,
                    prompt=?, negative_prompt=?, model=?, sampler=?, steps=?,
                    cfg=?, seed=?, workflow_json=?, metadata_json=?,
                    thumbnail_path=?, indexed_at=?, is_duplicate=?
                WHERE filepath=?
            ''', data[1:] + (str(filepath),))
        else:
            c.execute('''
                INSERT INTO images (
                    filepath, filename, source_name, source_path, file_size, file_hash,
                    width, height, created_at, modified_at, file_type,
                    prompt, negative_prompt, model, sampler, steps,
                    cfg, seed, workflow_json, metadata_json, thumbnail_path, indexed_at, is_duplicate
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ''', data)
        
        conn.commit()
    except Exception as e:
        pass
    
    conn.close()
    return filepath.name

def scan_all_sources(progress_callback=None):
    """Scan all sources"""
    all_files = []
    sources = get_sources()
    
    for source in sources:
        source_path = Path(source['path'])
        if not source_path.exists():
            print(f"⚠️  Folder not found: {source['path']}")
            continue
        
        print(f"📁 Scanning: {source['name']}")
        
        for root, dirs, files in os.walk(source_path):
            for filename in files:
                if Path(filename).suffix.lower() in ALL_EXTENSIONS:
                    filepath = Path(root) / filename
                    all_files.append((filepath, source['name'], source['path']))
    
    print(f"\n📊 Found {len(all_files)} files")
    
    if not all_files:
        return
    
    processed = 0
    with ThreadPoolExecutor(max_workers=4) as executor:
        for result in executor.map(scan_single_file, all_files):
            processed += 1
            if progress_callback:
                progress_callback(processed, len(all_files))
            if processed % 100 == 0:
                print(f"   Processed: {processed}/{len(all_files)}")
    
    print(f"✅ Scan complete: {processed} files processed")

# =============================================================================
# API ROUTES
# =============================================================================

@app.route('/')
def index():
    """Main page or setup wizard"""
    if not is_setup_complete():
        return redirect(url_for('setup'))
    return render_template('index.html', sources=get_sources(), version=__version__)

@app.route('/setup')
def setup():
    """Setup wizard page"""
    return render_template('setup.html', version=__version__)

@app.route('/api/setup/complete', methods=['POST'])
def api_setup_complete():
    """Mark setup as complete"""
    config = load_config()
    config['setup_complete'] = True
    save_config(config)
    return jsonify({'success': True})

@app.route('/api/sources')
def api_sources():
    """Get source list"""
    sources = get_sources()
    for source in sources:
        source['exists'] = Path(source['path']).exists()
    return jsonify(sources)

@app.route('/api/sources/add', methods=['POST'])
def api_add_source():
    """Add new source"""
    data = request.json
    
    path = data.get('path', '').strip()
    name = data.get('name', '').strip()
    color = data.get('color', '').strip()
    
    if not path:
        return jsonify({'error': 'Folder path is required'}), 400
    
    path = path.replace('\\', '/').rstrip('/')
    
    if not Path(path).exists():
        return jsonify({'error': f'Folder not found: {path}'}), 400
    
    if not Path(path).is_dir():
        return jsonify({'error': f'Not a folder: {path}'}), 400
    
    if not name:
        name = Path(path).name or path.split('/')[-2] or "New Folder"
    
    if not color:
        color = get_random_color()
    
    config = load_config()
    sources = config.get('sources', [])
    
    for source in sources:
        if source['path'].replace('\\', '/').rstrip('/') == path:
            return jsonify({'error': 'This folder is already added'}), 400
    
    new_source = {
        'name': name,
        'path': path,
        'color': color
    }
    sources.append(new_source)
    config['sources'] = sources
    save_config(config)
    
    return jsonify({'success': True, 'source': new_source})

@app.route('/api/sources/remove', methods=['POST'])
def api_remove_source():
    """Remove source"""
    data = request.json
    path = data.get('path', '').replace('\\', '/').rstrip('/')
    
    config = load_config()
    sources = config.get('sources', [])
    new_sources = [s for s in sources if s['path'].replace('\\', '/').rstrip('/') != path]
    
    if len(new_sources) == len(sources):
        return jsonify({'error': 'Source not found'}), 404
    
    config['sources'] = new_sources
    save_config(config)
    
    return jsonify({'success': True})

@app.route('/api/sources/validate', methods=['POST'])
def api_validate_source():
    """Validate folder path"""
    data = request.json
    path = data.get('path', '').strip()
    
    if not path:
        return jsonify({'valid': False, 'error': 'Path is empty'})
    
    path = path.replace('\\', '/').rstrip('/')
    path_obj = Path(path)
    
    if not path_obj.exists():
        return jsonify({'valid': False, 'error': 'Folder not found'})
    
    if not path_obj.is_dir():
        return jsonify({'valid': False, 'error': 'Not a folder'})
    
    file_count = 0
    try:
        for root, dirs, files in os.walk(path_obj):
            for f in files:
                if Path(f).suffix.lower() in ALL_EXTENSIONS:
                    file_count += 1
            if root != str(path_obj):
                depth = len(Path(root).relative_to(path_obj).parts)
                if depth > 5:
                    break
    except Exception as e:
        return jsonify({'valid': False, 'error': f'Read error: {str(e)}'})
    
    return jsonify({
        'valid': True,
        'file_count': file_count,
        'path': path
    })

@app.route('/api/images')
def api_images():
    """Image list API"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    source = request.args.get('source', '')
    search = request.args.get('search', '')
    model = request.args.get('model', '')
    file_type = request.args.get('type', '')
    year = request.args.get('year', '')
    month = request.args.get('month', '')
    show_duplicates = request.args.get('duplicates', 'false') == 'true'
    sort_by = request.args.get('sort', 'created_at')
    sort_order = request.args.get('order', 'desc')
    
    conn = get_db()
    c = conn.cursor()
    
    where_clauses = []
    params = []
    
    if not show_duplicates:
        where_clauses.append('(is_duplicate = 0 OR is_duplicate IS NULL)')
    
    if source:
        where_clauses.append('source_name = ?')
        params.append(source)
    
    if search:
        keywords = search.strip().split()
        for keyword in keywords:
            keyword_pattern = f'%{keyword}%'
            where_clauses.append('''(
                prompt LIKE ? OR 
                negative_prompt LIKE ? OR
                filename LIKE ? OR 
                model LIKE ? OR 
                sampler LIKE ? OR
                seed LIKE ? OR
                source_name LIKE ?
            )''')
            params.extend([keyword_pattern] * 7)
    
    if model:
        where_clauses.append('model LIKE ?')
        params.append(f'%{model}%')
    
    if file_type:
        where_clauses.append('file_type = ?')
        params.append(file_type)
    
    if year:
        where_clauses.append("strftime('%Y', created_at) = ?")
        params.append(year)
    
    if month:
        where_clauses.append("strftime('%m', created_at) = ?")
        params.append(month)
    
    where_sql = ' AND '.join(where_clauses) if where_clauses else '1=1'
    
    c.execute(f'SELECT COUNT(*) FROM images WHERE {where_sql}', params)
    total = c.fetchone()[0]
    
    valid_sorts = ['created_at', 'modified_at', 'filename', 'file_size']
    if sort_by not in valid_sorts:
        sort_by = 'created_at'
    order = 'DESC' if sort_order == 'desc' else 'ASC'
    
    offset = (page - 1) * per_page
    
    c.execute(f'''
        SELECT id, filepath, filename, source_name, file_size,
               width, height, created_at, file_type, prompt,
               model, sampler, steps, cfg, seed, thumbnail_path
        FROM images
        WHERE {where_sql}
        ORDER BY {sort_by} {order}
        LIMIT ? OFFSET ?
    ''', params + [per_page, offset])
    
    images = []
    for row in c.fetchall():
        ext = Path(row['filename']).suffix.lower() if row['filename'] else ''
        
        images.append({
            'id': row['id'],
            'filepath': row['filepath'],
            'filename': row['filename'],
            'extension': ext,
            'source': row['source_name'],
            'size': row['file_size'],
            'width': row['width'],
            'height': row['height'],
            'created_at': row['created_at'],
            'type': row['file_type'],
            'is_video': ext in VIDEO_EXTENSIONS,
            'is_gif': ext == '.gif',
            'prompt': row['prompt'][:200] + '...' if row['prompt'] and len(row['prompt']) > 200 else row['prompt'],
            'model': row['model'],
            'sampler': row['sampler'],
            'steps': row['steps'],
            'cfg': row['cfg'],
            'seed': row['seed'],
            'has_thumbnail': bool(row['thumbnail_path'])
        })
    
    conn.close()
    
    return jsonify({
        'images': images,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page
    })

@app.route('/api/image/<int:image_id>')
def api_image_detail(image_id):
    """Single image details"""
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM images WHERE id = ?', (image_id,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        abort(404)
    
    return jsonify({
        'id': row['id'],
        'filepath': row['filepath'],
        'filename': row['filename'],
        'source': row['source_name'],
        'size': row['file_size'],
        'width': row['width'],
        'height': row['height'],
        'created_at': row['created_at'],
        'modified_at': row['modified_at'],
        'type': row['file_type'],
        'prompt': row['prompt'],
        'negative_prompt': row['negative_prompt'],
        'model': row['model'],
        'sampler': row['sampler'],
        'steps': row['steps'],
        'cfg': row['cfg'],
        'seed': row['seed'],
        'workflow': json.loads(row['workflow_json']) if row['workflow_json'] else None,
        'metadata': json.loads(row['metadata_json']) if row['metadata_json'] else None
    })

@app.route('/api/models')
def api_models():
    """List of models used"""
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        SELECT model, COUNT(*) as count 
        FROM images 
        WHERE model != '' 
        GROUP BY model 
        ORDER BY count DESC
    ''')
    models = [{'name': row[0], 'count': row[1]} for row in c.fetchall()]
    conn.close()
    return jsonify(models)

@app.route('/api/years')
def api_years():
    """List of years"""
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        SELECT strftime('%Y', created_at) as year, COUNT(*) as count 
        FROM images 
        WHERE created_at IS NOT NULL AND created_at != ''
        GROUP BY year 
        ORDER BY year DESC
    ''')
    years = [{'year': row[0], 'count': row[1]} for row in c.fetchall() if row[0]]
    conn.close()
    return jsonify(years)

@app.route('/api/stats')
def api_stats():
    """Statistics"""
    conn = get_db()
    c = conn.cursor()
    
    stats = {}
    
    c.execute('SELECT COUNT(*) FROM images WHERE is_duplicate = 0 OR is_duplicate IS NULL')
    stats['total'] = c.fetchone()[0]
    
    c.execute('SELECT COUNT(*) FROM images')
    stats['total_with_duplicates'] = c.fetchone()[0]
    
    c.execute('SELECT COUNT(*) FROM images WHERE is_duplicate = 1')
    stats['duplicates'] = c.fetchone()[0]
    
    c.execute('SELECT source_name, COUNT(*) FROM images WHERE is_duplicate = 0 OR is_duplicate IS NULL GROUP BY source_name')
    stats['by_source'] = {row[0]: row[1] for row in c.fetchall()}
    
    c.execute('SELECT file_type, COUNT(*) FROM images WHERE is_duplicate = 0 OR is_duplicate IS NULL GROUP BY file_type')
    stats['by_type'] = {row[0]: row[1] for row in c.fetchall()}
    
    conn.close()
    return jsonify(stats)

@app.route('/api/scan')
def api_scan():
    """Full rescan"""
    def do_scan():
        scan_all_sources()
    
    thread = threading.Thread(target=do_scan)
    thread.start()
    
    return jsonify({'status': 'started', 'message': 'Scan started'})

@app.route('/api/refresh')
def api_refresh():
    """Quick refresh - scan only new files"""
    def do_quick_scan():
        print("\n🔄 Quick scan starting...")
        sources = get_sources()
        new_files = []
        
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT filepath FROM images')
        existing_paths = set(row[0] for row in c.fetchall())
        conn.close()
        
        for source in sources:
            source_path = Path(source['path'])
            if not source_path.exists():
                continue
            
            for root, dirs, files in os.walk(source_path):
                for filename in files:
                    if Path(filename).suffix.lower() in ALL_EXTENSIONS:
                        filepath = Path(root) / filename
                        if str(filepath) not in existing_paths:
                            new_files.append((filepath, source['name'], source['path']))
        
        if new_files:
            print(f"📊 Found {len(new_files)} new files")
            with ThreadPoolExecutor(max_workers=4) as executor:
                list(executor.map(scan_single_file, new_files))
            print(f"✅ New files added")
        else:
            print("✅ No new files found")
    
    thread = threading.Thread(target=do_quick_scan)
    thread.start()
    
    return jsonify({'status': 'started', 'message': 'Quick scan started'})

@app.route('/thumbnail/<int:image_id>')
def serve_thumbnail(image_id):
    """Serve thumbnail"""
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT filepath, thumbnail_path FROM images WHERE id = ?', (image_id,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        abort(404)
    
    thumb_path = row['thumbnail_path']
    
    if thumb_path and Path(thumb_path).exists():
        return send_file(thumb_path, mimetype='image/jpeg')
    
    filepath = row['filepath']
    if Path(filepath).exists():
        thumb_path = get_thumbnail_path(filepath)
        if create_thumbnail(filepath, thumb_path):
            return send_file(thumb_path, mimetype='image/jpeg')
        return send_file(filepath)
    
    abort(404)

@app.route('/image/<int:image_id>')
def serve_image(image_id):
    """Serve original image/video"""
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT filepath, filename FROM images WHERE id = ?', (image_id,))
    row = c.fetchone()
    conn.close()
    
    if not row or not Path(row['filepath']).exists():
        abort(404)
    
    filepath = Path(row['filepath'])
    ext = filepath.suffix.lower()
    
    mime_types = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.mp4': 'video/mp4',
        '.webm': 'video/webm',
        '.mov': 'video/quicktime',
        '.avi': 'video/x-msvideo',
        '.mkv': 'video/x-matroska',
        '.m4v': 'video/mp4',
    }
    
    mimetype = mime_types.get(ext, 'application/octet-stream')
    
    return send_file(row['filepath'], mimetype=mimetype)

@app.route('/workflow/<int:image_id>')
def download_workflow(image_id):
    """Download workflow JSON"""
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT filename, workflow_json FROM images WHERE id = ?', (image_id,))
    row = c.fetchone()
    conn.close()
    
    if not row or not row['workflow_json']:
        abort(404)
    
    filename = Path(row['filename']).stem + '_workflow.json'
    
    return send_file(
        BytesIO(row['workflow_json'].encode()),
        mimetype='application/json',
        as_attachment=True,
        download_name=filename
    )

# =============================================================================
# MAIN
# =============================================================================

def print_banner():
    """Print startup banner"""
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║            🎨 COMFY GALLERY v{__version__}                       ║
║                                                              ║
║     Universal ComfyUI Output Browser                         ║
║     Browse, organize, and manage all your AI generations     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """)

if __name__ == '__main__':
    print_banner()
    
    # Initialize database
    print("📦 Initializing database...")
    init_db()
    
    # Check if setup is needed
    if not is_setup_complete():
        print("\n🚀 First time setup required!")
        print(f"   Opening browser to http://{SERVER_HOST}:{SERVER_PORT}/setup")
        
        # Open browser after short delay
        def open_browser():
            import time
            time.sleep(1.5)
            webbrowser.open(f'http://{SERVER_HOST}:{SERVER_PORT}/setup')
        
        threading.Thread(target=open_browser, daemon=True).start()
    else:
        # Load and check sources
        sources = get_sources()
        print(f"\n📁 Configured sources: {len(sources)}")
        for source in sources:
            exists = Path(source['path']).exists()
            status = "✅" if exists else "❌"
            print(f"   {status} {source['name']}")
            print(f"      └─ {source['path']}")
        
        # Scan files
        print("\n🔍 Scanning files...")
        scan_all_sources()
        
        # Open browser
        def open_browser():
            import time
            time.sleep(1.5)
            webbrowser.open(f'http://{SERVER_HOST}:{SERVER_PORT}')
        
        threading.Thread(target=open_browser, daemon=True).start()
    
    # Start server
    print(f"\n🚀 Server starting: http://{SERVER_HOST}:{SERVER_PORT}")
    print("   Press Ctrl+C to stop\n")
    
    try:
        app.run(host=SERVER_HOST, port=SERVER_PORT, debug=False, threaded=True)
    except OSError as e:
        if "10013" in str(e) or "Permission" in str(e):
            print(f"\n❌ Error: Port {SERVER_PORT} is blocked or requires admin privileges.")
            print("   Try one of these solutions:")
            print(f"   1. Run as Administrator")
            print(f"   2. Change SERVER_PORT in comfy_gallery.py to another port (e.g., 8200)")
            print(f"   3. Check if antivirus/firewall is blocking the connection")
        else:
            print(f"\n❌ Error starting server: {e}")
        input("\nPress Enter to exit...")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        input("\nPress Enter to exit...")
