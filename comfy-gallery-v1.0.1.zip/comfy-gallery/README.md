# 🎨 Comfy Gallery

A fast, beautiful, and universal gallery to browse and manage all your ComfyUI outputs.

![Python](https://img.shields.io/badge/Python-3.9+-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)

## ✨ Features

- 📁 **Multi-folder Support** - Add multiple ComfyUI output folders from different locations
- 🔍 **Metadata Extraction** - View prompts, models, seeds, and generation parameters
- 📥 **Workflow Download** - Download ComfyUI workflow JSON with one click
- 🎬 **Video Support** - Browse videos and GIFs alongside images
- 🔎 **Powerful Search** - Search by keywords across prompts, models, filenames, and seeds
- 📅 **Date Filters** - Filter by year, month, or file type
- 🚫 **Duplicate Detection** - Automatically detects and hides duplicate files
- ⚡ **Fast Thumbnails** - Smart caching for quick browsing
- 📱 **Responsive Design** - Works on desktop and mobile

## 🚀 Quick Start

### Windows

1. Download and extract the latest release
2. Double-click `start.bat`
3. Follow the setup wizard in your browser

### Manual Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/comfy-gallery.git
cd comfy-gallery

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate
# Activate (Linux/macOS)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run
python comfy_gallery.py
```

## 📖 Usage

### First Time Setup

When you first run Comfy Gallery, a setup wizard will guide you through:

1. **Welcome Screen** - Overview of features
2. **Add Folders** - Add your ComfyUI output folder(s)
3. **Launch** - Start browsing your gallery

### Adding Output Folders

You can add folders in two ways:

1. **During Setup** - Add folders in the setup wizard
2. **Anytime** - Click the "+ Add" button in the sidebar

To find your folder path:

1. Open Windows Explorer
2. Navigate to your ComfyUI output folder
3. Click on the address bar (path will be selected)
4. Press `Ctrl+C` to copy
5. Paste in Comfy Gallery with `Ctrl+V`

### Browsing

- **Click** any image to open the lightbox with full details
- **Left/Right arrows** to navigate between images
- **Download Workflow** to get the ComfyUI workflow JSON
- **Copy Prompt** to copy the positive prompt

### Searching

Search works across:
- Positive and negative prompts
- Model names
- Filenames
- Sampler names
- Seeds

### Filtering

Use the sidebar filters:
- **Source** - Filter by folder
- **Type** - Images or videos
- **Year/Month** - Filter by creation date
- **Model** - Filter by checkpoint used

## ⚙️ Configuration

Configuration is stored in `config.json`. You can manually edit this file if needed.

```json
{
  "sources": [
    {
      "name": "Main Outputs",
      "path": "C:/ComfyUI/output",
      "color": "#8b5cf6"
    }
  ],
  "setup_complete": true,
  "theme": "dark"
}
```

## 📂 Project Structure

```
comfy-gallery/
├── comfy_gallery.py    # Main application
├── requirements.txt    # Python dependencies
├── start.bat           # Windows launcher
├── config.json         # User configuration (created on first run)
├── gallery.db          # SQLite database (created on first run)
├── cache/              # Thumbnail cache (created on first run)
│   └── thumbnails/
└── templates/
    ├── index.html      # Main gallery interface
    └── setup.html      # Setup wizard
```

## 🎥 Video Support

For video thumbnails, Comfy Gallery uses FFmpeg. If FFmpeg is not installed, a placeholder thumbnail will be shown.

To install FFmpeg:
- **Windows**: Download from [ffmpeg.org](https://ffmpeg.org/download.html) or use `choco install ffmpeg`
- **Linux**: `sudo apt install ffmpeg`
- **macOS**: `brew install ffmpeg`

## 🔧 Troubleshooting

### "Folder not found" error
- Make sure the path exists and is spelled correctly
- Use forward slashes `/` or escaped backslashes `\\` in paths

### Images not showing
- Click "Rescan" to rebuild the database
- Check that images are in supported formats (PNG, JPG, WebP, GIF)

### Slow loading
- The first scan may take a while for large collections
- Subsequent loads will be fast due to caching

### Port already in use
- Change `SERVER_PORT` in `comfy_gallery.py` to a different port (e.g., 8189)

## 📝 License

MIT License - feel free to use, modify, and distribute.

## 🙏 Credits

Created with ❤️ for the AI art community.

If you find this useful, please ⭐ star the repo!

---

**Enjoy browsing your AI art! 🎨**
